// Call the dataTables jQuery plugin
$(document).ready(function() {

});

async function login() {

    let datos= {};
    datos.jugid = document.getElementById("matricula").value;
    datos.jugPassword = document.getElementById("password").value;

    const request = await fetch('login', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(datos)
    });

    const  respuesta = await  request.text();

       if(respuesta == 'OK') {
           window.location.href = 'Jugadores.html'
       }else{
            alert("Las credenciales son incorrectas");
       }
}

function getHeaders() {
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',

    };
}