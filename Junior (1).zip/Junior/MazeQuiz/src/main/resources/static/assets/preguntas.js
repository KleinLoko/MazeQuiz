// Call the dataTables jQuery plugin
$(document).ready(function() {
    cargarPreguntas();
});

async function cargarPreguntas() {
    const request = await fetch('pregunta', {
      method: 'GET',
      headers: getHeaders()
    });

    const preguntaGrup = await  request.json();




    let listadoHtml = '';

    preguntaGrup.forEach(item=>{
        var id = item[0];
        var pregunta = item[1];
        var puntaje = item[2];
        console.log(id);

        let botonEliminar = '<button onclick="eliminarPregunta('+ id +')" type="button" class="btn btn-outline-danger">Borrar</button>';
        let botonModificar = '<button  onclick="cargarPregunta('+ id +')" class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBackdrop" aria-controls="offcanvasWithBackdrop">Editar</button>';
        let  preguntaHtml = '<tr><td>'+ id +'</td><td>' + pregunta + '</td><td>' + puntaje + '</td> <td>'+ botonEliminar +' ' + botonModificar +'</td></tr>';

        listadoHtml += preguntaHtml;

    });

    /*for(let preguntaTemp of preguntaGrup){

      let botonEliminar = '<button onclick="eliminarPregunta('+ preguntaTemp.pregId +')" type="button" class="btn btn-outline-danger">Borrar</button>';

      let botonModificar = '<button  onclick="cargarPregunta('+ preguntaTemp.pregId +')" class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBackdrop" aria-controls="offcanvasWithBackdrop">Editar</button>';

      let  preguntaHtml = '<tr><td>'+preguntaTemp.pregId+'</td><td>' + preguntaTemp.pregDescrip + '</td><td>'+preguntaTemp.pregValor +  '</td> <td>'+ botonEliminar +' ' + botonModificar +'</td></tr>';
      listadoHtml += preguntaHtml;
    }*/

    document.querySelector("#preguntasTabla tbody").outerHTML = listadoHtml;

    console.log("Si se está llamando al método");

    console.log(preguntaGrup);
}

async function eliminarPregunta(id){

  if (!confirm('¿Desea Eliminar El usuario?')){
    return;
  }
  const request = await fetch('eliminarpregunta/' + id, {
    method: 'DELETE',
    headers: getHeaders()
  });

  location.reload();
}

async function cargarPregunta(id) {
  const request = await fetch('pregunta/' + id, {
    method: 'GET',
    headers: getHeaders()
  });

  const PreguntaLoad = await  request.json();

  document.getElementById("InDescrip").value = PreguntaLoad.pregDescrip;
  document.getElementById("InValor").value = PreguntaLoad.pregValor;

  console.log("Si se está llamando al método");
}

function getHeaders() {
  return {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };
}