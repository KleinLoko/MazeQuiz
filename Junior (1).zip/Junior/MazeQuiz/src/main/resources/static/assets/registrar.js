// Call the dataTables jQuery plugin
$(document).ready(function() {

});

async function registrarJugador() {

    let datos= {};
    datos.jugNombre = document.getElementById("nombre").value;
    datos.jugApellidoPat = document.getElementById("apellidoPat").value;
    datos.jugApellidoMat = document.getElementById("apellidoMat").value;
    datos.jugCarrera = "ITC";
    datos.jugPuntaje = "0"
    datos.jugPassword = document.getElementById("password").value;

    const request = await fetch('guardarjugador', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(datos)
    });

    alert("Se agregó el jugador");
    console.log("Si se está llamando al método");
}

function getHeaders() {
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',

    };
}