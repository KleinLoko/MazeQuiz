package com.proyectofinal.MazeQuiz.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name =  "pregunta")
public class Pregunta {

    @Id
    @Getter @Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column( name="pregid" )
    private int pregId;

    @Getter @Setter
    @Column ( name="preg_descrip", nullable = false )
    private String pregDescrip;

    @Getter @Setter
    @Column(name = "preg_Valor")
    private int pregValor;

    @Getter
    @Setter
    @OneToMany(mappedBy = "pregunta")
    private List<Quiz> quizzes = new ArrayList<>();


    public Pregunta(int pregId, String pregDescrip, List<Quiz> quizzes, int pregValor) {
        this.pregId = pregId;
        this.pregDescrip = pregDescrip;
        this.quizzes = quizzes;
        this.pregValor = pregValor;
    }

    public Pregunta(int pregId, String predDescrip, int pregValor){
        this.pregId = pregId;
        this.pregDescrip = predDescrip;
        this.pregValor = pregValor;
    }

    //constructor vacío
    public Pregunta() {
    }
}
