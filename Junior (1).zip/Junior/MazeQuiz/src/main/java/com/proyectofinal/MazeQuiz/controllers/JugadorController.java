package com.proyectofinal.MazeQuiz.controllers;

import com.proyectofinal.MazeQuiz.dao.JugadorDAO;
import com.proyectofinal.MazeQuiz.models.Jugador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class JugadorController implements JugadorDAO{

    @Autowired
    private JugadorDAO jugadorDAO;

    @Override
    @RequestMapping( value = "jugador", method = RequestMethod.GET)
    public List<Jugador> getJugadores() {
       return jugadorDAO.getJugadores();
    }

    @RequestMapping( value = "jugador/{id}", method = RequestMethod.GET)
    public Jugador getJugador(@PathVariable int id) {
        return jugadorDAO.getJugador(id);
    }

    @RequestMapping(value = "guardarjugador", method = RequestMethod.POST)
    public void registrarJugador(@RequestBody Jugador jugador) {
        jugadorDAO.registrarJugador(jugador);
    }

    @RequestMapping(value = "eliminarjugador/{id}", method = RequestMethod.DELETE)
    public void eliminar(@PathVariable int id){
        jugadorDAO.eliminar(id);
    }

    @Override
    public boolean verificarCredenciales(Jugador jugador) {
        return false;
    }

}
