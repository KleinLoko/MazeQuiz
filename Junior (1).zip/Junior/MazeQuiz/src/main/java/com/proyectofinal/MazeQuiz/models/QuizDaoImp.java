package com.proyectofinal.MazeQuiz.models;

import com.proyectofinal.MazeQuiz.dao.QuizDAO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class QuizDaoImp implements QuizDAO {


    @PersistenceContext
    EntityManager entityManager;


    @Override
    public List<Quiz> getQuizs() {
        String query = "SELECT q.idQuiz, q.pregunta.pregId, q.pregunta.pregDescrip, " +
                "q.respuesta.resID, q.respuesta.resDescrip, q.quizValue " +
                "FROM Quiz q JOIN q.pregunta p JOIN q.respuesta r";

        //String query = "From Quiz";
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    public Quiz getQuiz(int id) {
        Quiz quiz = entityManager.find(Quiz.class,  id);
        return quiz;
    }

    @Override
    public void registrarQuiz(Quiz quiz) {
        entityManager.merge(quiz);

    }

    @Override
    public void eliminarQuiz(int id) {
        Quiz quiz = entityManager.find(Quiz.class,  id);
        entityManager.remove(quiz);
    }
}
