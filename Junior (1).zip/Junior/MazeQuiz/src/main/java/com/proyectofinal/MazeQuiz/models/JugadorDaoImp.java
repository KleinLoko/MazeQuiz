package com.proyectofinal.MazeQuiz.models;

import com.proyectofinal.MazeQuiz.dao.JugadorDAO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class JugadorDaoImp implements JugadorDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public List<Jugador> getJugadores(){
        String query = "FROM Jugador";
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    public Jugador getJugador(int id) {
        Jugador jugador =  entityManager.find(Jugador.class,  id);
        return jugador;
    }

    @Override
    public void registrarJugador(Jugador jugador) {
        entityManager.merge(jugador);
    }

    @Override
    public void eliminar(int id) {
        Jugador jugador =  entityManager.find(Jugador.class,  id);
        entityManager.remove(jugador);
    }

    @Override
    public boolean verificarCredenciales(Jugador jugador) {
        String query = "FROM Jugador WHERE jugid = :matricula AND jugPassword = :password ";
        List<Jugador> lista = entityManager.createQuery(query)
                .setParameter("matricula", jugador.getJugid()).
                setParameter("password", jugador.getJugPassword())
                .getResultList();

        if(lista.isEmpty()){
            return false;
        }else{
            return true;
        }
    }
}
