package com.proyectofinal.MazeQuiz.models;

import com.proyectofinal.MazeQuiz.dao.RespuestaDAO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class RespuestaDaoImp implements RespuestaDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public List<Respuesta> getRespuestas(){
        String query = "FROM Respuesta";
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    public Respuesta getRespuesta(int id) {
        Respuesta respuesta =  entityManager.find(Respuesta.class,  id);
        return respuesta;
    }

    @Override
    public void registrarRespuesta(Respuesta respuesta){
        entityManager.merge(respuesta);
    }

    @Override
    public void eliminarRespuesta(int id) {
        Respuesta respuesta  = entityManager.find(Respuesta.class ,  id);
        entityManager.remove(respuesta);
    }

}
