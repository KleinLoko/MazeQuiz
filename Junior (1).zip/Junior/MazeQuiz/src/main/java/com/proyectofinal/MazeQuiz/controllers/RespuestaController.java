package com.proyectofinal.MazeQuiz.controllers;

import com.proyectofinal.MazeQuiz.dao.RespuestaDAO;
import com.proyectofinal.MazeQuiz.models.Respuesta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class RespuestaController implements RespuestaDAO{

    @Autowired
    private RespuestaDAO respestaDAO;

    @Override
    @RequestMapping( value = "respuesta", method = RequestMethod.GET)
    public List<Respuesta> getRespuestas() {
        return respestaDAO.getRespuestas();
    }

    @RequestMapping( value = "respuesta/{id}", method = RequestMethod.GET)
    public Respuesta getRespuesta(@PathVariable int id) {
        return respestaDAO.getRespuesta(id);
    }

    @RequestMapping(value = "guardarrespuesta", method = RequestMethod.POST)
    public void registrarRespuesta(@RequestBody Respuesta jugador) {
        respestaDAO.registrarRespuesta(jugador);
    }

    @RequestMapping(value = "eliminarrespuesta/{id}", method = RequestMethod.DELETE)
    public void eliminarRespuesta(@PathVariable int id){
        respestaDAO.eliminarRespuesta(id);
    }

}
