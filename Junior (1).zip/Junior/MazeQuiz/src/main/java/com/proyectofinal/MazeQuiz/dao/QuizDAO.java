package com.proyectofinal.MazeQuiz.dao;

import com.proyectofinal.MazeQuiz.models.Quiz;

import java.util.List;

public interface QuizDAO {

    //método que retornará todas los Quiz de la bd;
    List<Quiz> getQuizs();

    //retorna un Quiz con el id indicado;
    Quiz getQuiz(int id);

    //Resgitra una nueva respuesta en la base de datos;
    void registrarQuiz(Quiz quiz);

    //Elmina una respuesta de la base de datos;
    void eliminarQuiz(int id);

}
