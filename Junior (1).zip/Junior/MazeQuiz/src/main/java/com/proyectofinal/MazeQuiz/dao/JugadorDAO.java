package com.proyectofinal.MazeQuiz.dao;

import com.proyectofinal.MazeQuiz.models.Jugador;

import java.util.List;

public interface JugadorDAO {

    //método que retornará todas las preguntas de la bd;
    List<Jugador> getJugadores();

    Jugador getJugador(int id);

    void registrarJugador(Jugador jugador);

    void eliminar(int id);

    boolean verificarCredenciales(Jugador jugador);
}
 