package com.proyectofinal.MazeQuiz.controllers;

import com.proyectofinal.MazeQuiz.dao.PreguntaDAO;
import com.proyectofinal.MazeQuiz.models.Pregunta;
import com.proyectofinal.MazeQuiz.models.Respuesta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class PreguntaController implements PreguntaDAO {

    @Autowired
    private PreguntaDAO preguntaDAO;

    @Override
    @RequestMapping( value = "pregunta", method = RequestMethod.GET)
    public List<Pregunta> getPreguntas(){
        return preguntaDAO.getPreguntas();
    }

    @RequestMapping( value = "pregunta/{id}", method = RequestMethod.GET)
    public Pregunta getPregunta(@PathVariable int id) {return preguntaDAO.getPregunta(id);}

    @RequestMapping(value = "guardarpregunta", method = RequestMethod.POST)
    public void registrarPregunta(@RequestBody Pregunta pregunta){
        preguntaDAO.registrarPregunta(pregunta);
    }

    @RequestMapping(value = "eliminarpregunta/{id}", method = RequestMethod.DELETE)
    public void eliminarPrgunta(@PathVariable int id) { preguntaDAO.eliminarPrgunta(id);

    }


}
