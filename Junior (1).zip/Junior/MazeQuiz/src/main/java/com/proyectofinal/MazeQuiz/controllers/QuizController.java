package com.proyectofinal.MazeQuiz.controllers;

import com.proyectofinal.MazeQuiz.dao.QuizDAO;
import com.proyectofinal.MazeQuiz.models.Quiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
public class QuizController implements QuizDAO {

    @Autowired
    QuizDAO quizDAO;

    @Override
    @RequestMapping( value = "quiz", method = RequestMethod.GET)
    public List<Quiz> getQuizs() { return quizDAO.getQuizs(); }

    @Override
    @RequestMapping( value = "quiz/{id}", method = RequestMethod.GET)
    public Quiz getQuiz(int id) { return quizDAO.getQuiz(id);}

    @Override
    @RequestMapping(value = "guardarquiz", method = RequestMethod.POST)
    public void registrarQuiz(Quiz quiz) { quizDAO.registrarQuiz(quiz);}

    @Override
    @RequestMapping(value = "eliminarquiz/{id}", method = RequestMethod.DELETE)
    public void eliminarQuiz(int id) {quizDAO.eliminarQuiz(id);}
}
