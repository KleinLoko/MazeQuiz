package com.proyectofinal.MazeQuiz.models;

import com.proyectofinal.MazeQuiz.dao.PreguntaDAO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class PreguntaDaoImp implements PreguntaDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public List<Pregunta> getPreguntas(){
        String query = "SELECT p.pregId , p.pregDescrip, p.pregValor FROM Pregunta p";
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    public Pregunta getPregunta(int id) {
        Pregunta pregunta =  entityManager.find(Pregunta.class,  id);
        return pregunta;
    }

    @Override
    public void registrarPregunta(Pregunta pregunta){
        entityManager.merge(pregunta);
    }

    @Override
    public void eliminarPrgunta(int id) {
        Pregunta pregunta = entityManager.find(Pregunta.class ,  id);
        entityManager.remove(pregunta);
    }



}
