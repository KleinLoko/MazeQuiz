package com.proyectofinal.MazeQuiz.dao;

import com.proyectofinal.MazeQuiz.models.Pregunta;
import com.proyectofinal.MazeQuiz.models.Respuesta;

import java.util.List;

public interface PreguntaDAO {

    //método que retornará todas las preguntas de la bd;
    List<Pregunta> getPreguntas();

    void registrarPregunta(Pregunta pregunta);

    void eliminarPrgunta(int id);

    Pregunta getPregunta(int id);
}
