package com.proyectofinal.MazeQuiz.dao;

import com.proyectofinal.MazeQuiz.models.Respuesta;

import java.util.List;

public interface RespuestaDAO {

    //método que retornará todas las respuestas de la bd;
    List<Respuesta> getRespuestas();

    //retorna una respuesta con el id indicado;
    Respuesta getRespuesta(int id);

    //Resgitra una nueva respuesta en la base de datos;
    void registrarRespuesta(Respuesta respuesta);

    //Elmina una respuesta de la base de datos;
    void eliminarRespuesta(int id);

}
